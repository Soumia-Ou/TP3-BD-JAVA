import java.util.Arrays;

public class Agence {
	 // Déclaration des attributs (caractéristiques) de l'agence :
	private  String numero;  // Numéro unique de l'agence
	private String adresse;  // Adresse de l'agence
	
	//static montre qu'il n'y a qu'une seule instance de cette variable partagée par toutes les instances de la classe.
    // Variables statiques pour suivre le nombre total de clients, le nombre total de comptes et le nombre total d'agences
	private static int NbClients=0;
	private static int NbComptes=0; 
	private static int NbAgences=0;
	
	// Constantes définissant les limites du nombre maximal de clients et de comptes
	public final static int Max_Clients=100;
	public final static int Max_comptes=100;
	
	// Tableaux pour stocker les clients et les comptes de l'agence
	private Client[] lesclients;
	private Compte[] lescomptes;
	
	// Constructeur sans paramètres (utilisé par défaut)
	public Agence() {
		numero=this.getClass().getName()+":"+ ++NbAgences;
		this.adresse="";
		this.lesclients=null;
		this.lescomptes=null;
	}
	
	// Constructeur avec paramètre permettant de spécifier l'adresse de l'agence
	public Agence(String adresse) {
		numero=this.getClass().getName()+":"+ ++NbAgences;
		this.adresse=adresse;
		lesclients=new Client[Max_Clients]; // Initialisation du tableau de clients
		lescomptes=new Compte[Max_comptes]; // Initialisation du tableau de comptes
	}
	
	// Méthode pour modifier le numéro de l'agence
	public void setNumero(String numero) {
		this.numero = numero;
	}
	
	// Méthode pour modifier l'adresse de l'agence
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	
	// Méthode pour modifier le tableau de clients de l'agence
	public void setLesclients(Client[] lesclients) {
		this.lesclients = lesclients;
	}
	
	// Méthode pour modifier le tableau de comptes de l'agence
	public void setLescomptes(Compte[] lescomptes) {
		this.lescomptes = lescomptes;
	}
	
	
	// Méthode pour ajouter un client à la liste existante de clients de l'agence
	public void addClient(Client client) {
	    if(NbClients < Max_Clients) {
	    	lesclients[NbClients++]=client;
	    }
	}

	// Méthode pour ajouter un compte à la liste existante de comptes de l'agence
	public void addCompte(Compte compte) {
	    if(NbComptes < Max_comptes) {
	    	lescomptes[NbComptes++]=compte;	
	    }
	}
	
	// Méthode pour récupérer le numéro de l'agence
	public String getNumero() {
		return numero;
	}
	
	// Méthode pour récupérer l'adresse de l'agence
	public String getAdresse() {
		return adresse;
	}
	
	// Méthode pour récupérer un client spécifique de l'agence
	public Client getClient(int i) {
		if(i >= 0 && i < NbComptes){
			return lesclients[i];
		}
		return null;
	}
	
	// Méthode pour récupérer un compte spécifique de l'agence
	public Compte getCompte(int i) {
		if(i >= 0 && i < NbComptes){
			return lescomptes[i];
		}
		return null;
	}
	
	// Méthode pour récupérer le nombre total de clients de l'agence
	public int getNbClients() {
	    return NbClients;
	}

	// Méthode pour récupérer le nombre total de comptes de l'agence
	public int getNbCompte() {
	    return NbComptes;
	}

	// Méthode toString pour obtenir une représentation textuelle de l'agence
	//Arrays.toString est utiliser a fin de transmettre un tableau et le convertit en une représentation  lisible du contenu de ce tableau sous forme de chaîne de caractères
	@Override
	public String toString() {
	    return "Agence : Numero-> " + numero + "\tAdresse-> " + adresse +
	            "\tLes clients -> " + Arrays.toString(lesclients) +
	            "\tLes comptes -> " + Arrays.toString(lescomptes) + ".";
	}
	
	
}
