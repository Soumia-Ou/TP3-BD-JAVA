

public class Compte  {
	// Déclaration des attributs (caractéristiques) du compte :
	protected String code; // Code unique du compte
	protected double solde; // Solde actuel du compte
	
	// Références aux objets Agence et Client associés au compte
	protected Agence agence;
	protected Client proprietaire;
	
	// Variable statique pour suivre le nombre total de comptes
	private static int NbComptes = 0;
    
	// Constructeur d'initialisation
    public Compte(double solde, Client proprietaire ,Agence agence) {
        this.solde = solde;
        this.proprietaire = proprietaire;
        this.agence=agence;
        this.code = getClass() + ":" + (++NbComptes); // Génération du code unique du compte
    }
    
    // Constructeur par défaut
	public Compte(Client client , Agence agence) {
		this.code="";
		this.solde=0.0;
		this.agence=agence;
		this.proprietaire=client;
	}
	
	// Constructeur avec paramètres
		public Compte( double solde , Agence agence , Client proprietaire) {
			this.solde=solde;
			this.agence=agence;
			this.proprietaire=proprietaire;
		}
		
	// Méthode pour modifier le code du compte
	public void setCode(String code) {
		this.code = code;
	}
	
	// Méthode pour modifier le solde du compte
	public void setSolde(double solde) {
		this.solde = solde;
	}
	
	// Méthode pour modifier l'agence associée au compte
	public void setlAgence(Agence la) {
		this.agence = la;
	}
	
	// Méthode pour modifier le propriétaire du compte
	public void setProprietaire(Client prop) {
		this.proprietaire = prop;
	}
	
	// Méthode pour récupérer le code du compte
	public String getCode() {
		return code;
	}
		
	// Méthode pour récupérer le solde du compte 
	public double getSolde() {
		return solde;
	}
	
	 // Méthode pour récupérer l'agence associée au compte
	public Agence getlAgence() {
		return agence;
	}
		
	// Méthode pour récupérer le propriétaire du compte 
	public Client getProprietaire() {
		return proprietaire;
	}
		
	// Méthode pour déposer un montant sur le compte
	public void deposer(double Montant) {	
		 if (Montant > 0) {
			this.solde += Montant;
	        System.out.println("Dépôt de " + Montant + " sur le compte effectué avec succès.");
		 }
		 else
			 System.out.println("Le montant du dépôt doit être positif.");
	}

	// Méthode pour retirer un montant du compte
	public void retirer(double Montant) {
	     if (Montant > 0 && this.solde >= Montant) {
		     this.solde -= Montant;
		     System.out.println("Retrait de " + Montant + " sur le compte " + this.code + " effectué avec succès.");
		 }
	     else 
		     System.out.println("Solde insuffisant pour effectuer le retrait.");
	}
	
	// Méthode toString pour obtenir une représentation textuelle du compte
	@Override
	public String toString() {
		return "Compte : "+"Code-> "+code+"\tSolde-> "+solde+"\tLAgence-> "+agence+"\tPropriétaire-> "+proprietaire+".";
	}
		
		
		

	
}
