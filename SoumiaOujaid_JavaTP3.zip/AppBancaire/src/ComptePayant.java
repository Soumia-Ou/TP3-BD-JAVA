
//ComptePayant hérite de la classe Compte: cela signifie que ComptePayant bénéficie de toutes les caractéristiques (attributs et méthodes) de la classe Compte .
public class ComptePayant extends Compte {
	//Declaration de constante "Taux de frais" pour les opérations
	private final double Taux_Operation = 5.0;
	
	// Variable statique pour suivre le nombre total de comptes payants
	public static int NbComptePayant=0;
	
	//Constructeur sans paramètre :
	public ComptePayant(Client proprietaire , Agence agence) {
		super(proprietaire,agence);	 // Appelle le constructeur de la classe parente (Compte)
		String code=this.getClass().getName()+" : "+ ++NbComptePayant;
		setCode(code); // Définit le code unique pour le compte payant
	}
	
	// Constructeur avec paramètre pour spécifier le solde initial
	public  ComptePayant(double solde, Client proprietaire, Agence agence) {
		super(proprietaire,agence);
		this.solde = solde;
		String code=this.getClass().getName()+" : "+ ++NbComptePayant;
		setCode(code);
	}
	
	// Méthode pour déposer un montant, en appliquant le taux de frais
	public void deposer(double Montant) {	
		super.deposer(Montant - Taux_Operation); // Dépôt avec déduction du taux de frais
	}

	// Méthode pour retirer un montant, en appliquant le taux de frais
	public void retirer(double Montant) {
		super.retirer(Montant + Taux_Operation); // Retrait avec ajout du taux de frais
	}
	
	// Méthode toString pour obtenir une représentation textuelle du compte payant
	@Override
	public String toString() {
		return "Compte Payant " +getCode()+"-> ("+ "Solde :"+solde+" DH)";
	}
	
}
