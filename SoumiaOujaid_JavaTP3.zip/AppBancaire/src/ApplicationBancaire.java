import java.util.Arrays;
import java.util.Comparator;

public class ApplicationBancaire {
	// Constante définie le nombre maximal des clients dans le tableau des clients.
	public final static int Nb_Clients = 4;
	
    public static void main(String[] args) {
    	
    	// Codes ANSI pour changer les couleurs du texte
	    final String ANSI_RED = "\u001B[33m"; //texte sera affiché en rouge dans un terminal prenant en charge ANSI.
	    final String ANSI_BLUE = "\u001B[34m";
	    final String ANSI_RESET = "\u001B[0m"; //réinitialise la couleur par défaut.
	    
	    
	    //Creation d'une instance de la class Agence
    	Agence agence = new Agence("Tikiouine, Agadir ");
    	
    	String nom;
    	String prenom;
    	String adresse;
    	
    	//Creation des quatre clients avec différentes informations, puis les instances de clients sont stockées dans un tableau.
    	Client [] clients = new Client[4];
    	for(int i=0 ; i< Nb_Clients ; i++) {
    		nom = "Ou _ "+(i+1);
    		prenom = "Soumia _ "+(i+1);
    		adresse = "Agadir_"+(i+1);
    		clients[i] = new Client(agence,nom,prenom,adresse);
    	}
    	
    	//Affichage des infos des quatre clients ajoutés 
    	System.out.println(ANSI_RED + "\n \t \t \t \t \t \t Affichage des informations des clients : " + ANSI_RESET);
    	for(int i=0 ; i< Nb_Clients ; i++) {
    		System.out.print(clients[i].toString());
    	}
	    
    	//Ajouter des comptes aux clients :
    	
    	//client ayant un compte d’épargne (solde = 1000dh).
    	clients[0].addCompte(new CompteEpargne(1000, clients[0],agence));
    	
    	//Un client ayant un compte payant (solde = 2500dh).
    	clients[1].addCompte(new ComptePayant(2500, clients[1],agence));
    	
    	// Un client ayant 2 comptes payants (soldes 0dh et 3000dh).
    	clients[2].addCompte(new ComptePayant(3000, clients[2],agence));
    	clients[2].addCompte(new ComptePayant(0,clients[2],agence));
    	
    	//Un client avec un compte d’épargne et un compte payant (soldes 2300dh et 0dh)
    	clients[3].addCompte(new CompteEpargne(2300, clients[3], agence));
    	clients[3].addCompte(new ComptePayant(0, clients[3], agence));
    	
    	//Affichage des Comptes des clients ajoutés.
    	System.out.println(ANSI_RED + "\n \t \t \t \t \t \t  Affichage des Comptes des clients crées : " + ANSI_RESET);
    	for(int i=0 ; i< Nb_Clients ; i++) {
    		System.out.print(clients[i].getCompte(0)+"\t\t");
    		System.out.println(clients[i].getCompte(1));
    	}
	    
    	//Des montants sont déposés dans certains comptes clients.
    	System.out.println(ANSI_RED + "\n \t \t \t \t \t \t Depot dans  des Comptes des clients crées : " + ANSI_RESET);
    	
    	//Deposer dans le compte 1 du client 1 par deposer():
    	if(clients[0].getCompte(0)!=null) {
    		clients[0].getCompte(0).deposer(2000);
    	}else {
    		System.out.println("Ce compte c'existe pas ");
    	}
    	
    	//Deposer dans le compte 2 du client 3 par deposer():
    	if(clients[2].getCompte(1)!=null) {
    		clients[2].getCompte(1).deposer(5000);
    	}else {
    		System.out.println("Ce compte c'existe pas ");
    	}
    	
    	//Deposer dans le compte 2 du client 4 par deposer():
    	if(clients[3].getCompte(1)!=null) {
    		clients[3].getCompte(1).deposer(8000);
    	}else {
    		System.out.println("Ce compte c'existe pas ");
    	}
    	
    	//Affichage des comptes apres le depot :
    	System.out.println(ANSI_RED + "\n \t \t \t \t \t \t Affichage   des Comptes des clients crées apres Depot : " + ANSI_RESET);
    	for(int i=0 ; i< Nb_Clients ; i++) {
    		System.out.print(clients[i].getCompte(0)+"\t\t");
    		System.out.println(clients[i].getCompte(1));
    	}
    	
    	//Des montants sont retirés de certains comptes clients.
    	System.out.println(ANSI_RED + "\n \t \t \t \t \t \t Retrait dans  des Comptes des clients crées : " + ANSI_RESET);
    	
    	//Retrait de 1000 dans le compte 1 de client 1
    	if(clients[0].getCompte(0)!=null) {
    		clients[0].getCompte(0).retirer(1000);
    	}
    	
    	//Retrait de 2000 dans le compte 1 de client 2
    	if(clients[1].getCompte(0)!=null) {
    		clients[1].getCompte(0).retirer(2000);
    	}
    	
    	//Retrait de 2000 dans le compte 2 de client 3
    	if(clients[2].getCompte(1)!=null) {
    		clients[2].getCompte(1).retirer(400);
    	}
    	
    	//Retrait de 2000 dans le compte 2 de client 4
    	if(clients[3].getCompte(1)!=null) {
    		clients[3].getCompte(1).retirer(800);
    	}
    	
    	//Affichage des comptes apres le depot :
    	System.out.println(ANSI_RED + "\n \t \t \t \t \t \t Affichage   des Comptes des clients crées apres Retrait : " + ANSI_RESET);
    	for(int i=0 ; i< Nb_Clients ; i++) {
    		System.out.print(clients[i].getCompte(0)+"\t\t");
    		System.out.println(clients[i].getCompte(1));
    	}
    	
    	//Tous les clients et leurs comptes seront ajoutés à l'agence.
    	System.out.print(ANSI_RED + "\n \t \t \t \t \t \t Ajout des Clients  : " + ANSI_RESET);
    	
    	//Ajout des clients et de leurs comptes à l'agence 
    	for(int i=0 ; i< Nb_Clients ; i++){
    		agence.addClient(clients[i]);
    		for(int j=0; j< clients[i].getNbCompte(); j++){
    			agence.addCompte(clients[i].getCompte(j));
    		}
    	}
    	System.out.println(ANSI_BLUE + "\n \t \t \t \t \t \t Fait avec succès  !\n " + ANSI_RESET);
    	
    	//Utilisation de la méthode calculInteret pour les comptes épargne
    	System.out.println(ANSI_RED + "\n \t \t \t \t \t \t Usage de methode CalculInteret  : " + ANSI_RESET);
    	//La méthode calculInteret est appelée pour chaque compte épargne de l'agence.
    	for(int i=0; i< agence.getNbCompte(); i++){
    		if(agence.getCompte(i) instanceof CompteEpargne) {
    			((CompteEpargne) agence.getCompte(i)).calculInteret();
    		}
    	}
    	
    	// Affichage des différents clients avec leurs comptes 
    	System.out.println(ANSI_RED + "\n \t \t \t \t \t \t Liste des differents clients avec leurs differents comptes " + ANSI_RESET);
    	//Les informations sur chaque client et ses comptes seront affichées.
    	Client client;
    	for(int i=0; i< agence.getNbClients(); i++){
    		client = agence.getClient(i);
    		System.out.println(client.toString());
    			
    		for(int j=0; j<client.getNbCompte(); j++) {
    			System.out.println(client.getCompte(j).toString());
    		}
    	}
    	
    	//Affichage des comptes payants de l'agence 
    	System.out.println(ANSI_RED + "\n \t \t \t \t \t \t Liste des comptes d epargne de l agence " + ANSI_RESET);
    	//Les comptes payants de l'agence seront affichés.
    	for(int i=0; i< agence.getNbCompte(); i++) {
    		if(agence.getCompte(i) instanceof CompteEpargne) {
    				System.out.println(agence.getCompte(i).toString());
    		}
    	}
    		
    	// Liste des comptes payants de l’agence
        System.out.println(ANSI_RED + "\n \t \t \t \t \t \t Liste des comptes payants de l agence " + ANSI_RESET);
        	for(int i=0; i< agence.getNbCompte(); i++) {
        		if(agence.getCompte(i) instanceof ComptePayant) {
        			System.out.println(agence.getCompte(i).toString());
        		}
        	}
        	
    	//Calcul du solde total des comptes d'un client
        System.out.println(ANSI_RED + "\n \t \t \t \t \t \t Solde total des comptes d’un client " + ANSI_RESET);
        //Le solde total des comptes de chaque client sera calculé par méthode getSolTotal () et affiché.

        for(int i=0 ; i< Nb_Clients ; i++){		
         	System.out.println("Solde total des comptes de " + clients[i].getNom() + "->  (" + getSoldeTotal(clients[i]) +"DH)");
         }
        	 
        	 
        // Classement des clients selon le solde total
        System.out.println(ANSI_RED + "\n \t \t \t \t \t \t Classement des clients selon le solde total " + ANSI_RESET);
        
        //Les clients seront classés selon leur solde total et affichés en ordre décroissant
        // Tri du tableau clients en utilisant la méthode Arrays.sort() avec un comparateur personnalisE 
        Arrays.sort(clients, (client1, client2) -> {
            double soldeTotal1 = 0.0;
            double soldeTotal2 = 0.0;

            if (client1.getCompte(0) != null) {
                soldeTotal1 = client1.getCompte(0).getSolde();
                if (client1.getCompte(1) != null) {
                    soldeTotal1 += client1.getCompte(1).getSolde();
                }
            }

            if (client2.getCompte(0) != null) {
                soldeTotal2 = client2.getCompte(0).getSolde();
                if (client2.getCompte(1) != null) {
                    soldeTotal2 += client2.getCompte(1).getSolde();
                }
            }

          // Comparer les soldes totaux dans l'ordre décroissant
          return Double.compare(soldeTotal2, soldeTotal1);
        });

        // Afficher le classement des clients
        for (Client client1 : clients) {
            System.out.println(client1.getCode() + " -> " + getSoldeTotal(client1));
        }

      

        
    }  
    // Méthode pour calculer le solde total d'un client
    private static double getSoldeTotal(Client client) {
        double soldeTotal = 0.0;

        if (client.getCompte(0) != null) {
            soldeTotal = client.getCompte(0).getSolde();
            if (client.getCompte(1) != null) {
                soldeTotal += client.getCompte(1).getSolde();
            }
        }

        return soldeTotal;
    }
        
 }  




 
  
