
public class Client {
	// Déclaration des attributs (caractéristiques) du client :
	private String code; // Code unique du client
	private String nom;  // Nom du client
	private String prenom;   // Prénom du client
	private String adresse;  // Adresse du client
	
	// Constantes définissant les limites du nombre maximal de comptes et clients
	public final static int Max_Comptes=4;
	public final static int Max_Clients=10000;
	
	// Référence à l'agence à laquelle le client est associé
	private Agence monAgence;
	
	// Nombre de comptes du client
	private  int NbComptes=0;
	
	// Nombre total de clients (variable statique)
	private static int NbClients=0;
	
	// Tableau pour stocker les comptes du client
	private Compte[] mesComptes;
   
    
	// Constructeur d'initialisation du client avec son agence et ses informations personnelles
    public Client(Agence agence,String nom, String prenom , String adresse) {
    	code=this.getClass().getName()+":"+ ++NbClients;
        this.nom = nom;
        this.prenom = prenom;
        this.adresse=adresse;
        this.monAgence=agence;
        mesComptes=new Compte[Max_Comptes]; // Initialisation du tableau de comptes
        
    }
    
    // Constructeur alternatif sans informations personnelles (utilisé par défaut)
    public Client(Agence agence) {
    	code=this.getClass().getName()+":"+ ++NbClients;
    	monAgence=agence;
    	mesComptes=new Compte[Max_Comptes];
    	this.nom="";
		this.prenom="";
		this.adresse="";
    }

	
    // Méthode pour modifier le code du client
	public void setCode(String code) {
		this.code = code;
	}
	
	// Méthode pour modifier le nom du client
	public void setNom(String nom) {
			this.nom = nom;
		}
		
	// Méthode pour modifier le prénom du client
	public void setPrenom(String prenom) {
			this.prenom = prenom;
	}
	
	// Méthode pour modifier l'adresse du client 
	public void setAdresse(String adresse) {
		this.adresse=adresse;
	}
	
	// Méthode pour modifier l'agence associée au client
	public void setMonAgence(Agence monagence) {
		this.monAgence=monagence;
	}
	

    // Méthode pour ajouter un compte à la liste existante de comptes du client
	public void addCompte(Compte compte) {
	    if(NbComptes < Max_Comptes) {
	    	mesComptes[NbComptes++] = compte;
	    }
	    
	    else {
	    	System.out.println("Impossible d'ajouter d'autre compte !!");
	    }
	    
	}
	
	// Méthode pour savoir est ce que le client à effectuer un dépôt sur un compte spécifique ou Non
	public boolean deposer(int i, double Montant) {
		 if(i >= 0 && i < NbComptes){
		 	mesComptes[i].deposer(Montant);
		 	return true;
		 }
		 
		 else {
			 return false;
		 }
		  
	}
	
	// Méthode pour savoir est ce que le client à effectuer un retrait sur un compte spécifique ou Non
	public boolean retirer(int i , double Montant) {
		 if(i >= 0 && i < NbComptes){
		 	mesComptes[i].retirer(Montant);
		 	return true;
		 }
		 else {
			 return false; 
		 }
		 
		 
	}
	
	// Méthode pour récupérer le code du client 
	public String getCode() {
		return code;
	}
	
	// Méthode pour récupérer le nom du client
	public String getNom() {
		return nom;
	}
	
	
	// Méthode pour récupérer un compte spécifique du client
	public Compte getCompte(int i) {
		if(i >= 0 && i < NbComptes) {
		return mesComptes[i];
		}
		return null;
	}
	
	// Méthode pour récupérer le nombre de comptes du client
	public int getNbCompte() {
		return NbComptes;
	}
	
	// Méthode toString pour obtenir une représentation textuelle du client
	// @Override signifier que la méthode toString est une méthode de la classe Object qui est souvent surchargée dans la classe dérivée Client pour fournir une représentation textuelle significative de l'objet.
	@Override
	public String toString() {
		return " Code -> " + getCode() + "\t\t\t" + " Nom -> " + nom + "\t\t\t" + " Prenom -> " + prenom + "\t\t\t" + " Adresse -> " + adresse + "\t\t\t" +"Agence ->" +monAgence.getAdresse() +"." ;
	}
		
		
		

}
