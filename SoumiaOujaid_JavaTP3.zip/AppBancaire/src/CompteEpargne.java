
public class CompteEpargne  extends Compte{
	// Déclaration des attributs spécifiques à la classe CompteEpargne :
	public static double taux;  // Taux d'intérêt pour le compte épargne
	
	public static int NbComptesEpargne=0;  // Nombre total de comptes épargne créés
	
	//Constructeur sans paramètre :
	public CompteEpargne(Client client , Agence agence) {
		super(client,agence);  // Appelle le constructeur de la classe parente (Compte)
		String code=this.getClass().getName()+" : "+ ++NbComptesEpargne;
		setCode(code); // Définit le code unique pour le compte épargne
	}
	
	// Constructeur avec paramètres pour spécifier le solde initial
	public CompteEpargne(double solde , Client client , Agence agence ) {
		super(solde,client,agence);
		String code=this.getClass().getName()+" : "+ ++NbComptesEpargne;
		setCode(code);
	}
	
	// Méthode pour modifier le taux d'intérêt
	public void setTaux(double taux) {
		this.taux=taux;
	}
	
	// Méthode pour récupérer le nombre total de comptes épargne créés
	public static int getNbrcomptesE() {
		return NbComptesEpargne;
	}
	
	// Méthode pour récupérer le taux d'intérêt
	public double getTaux() {
		return taux;
	}
	
	// Méthode pour calculer et ajouter les intérêts au solde du compte épargne
	public void calculInteret() {
		double interet =this.solde * this.taux;
		this.solde += interet;
		System.out.println("Calcul d'interet s'est fait avec succès . \t Nouveau solde dans le compte du client  "+getProprietaire().getNom()+": "+this.solde+"\t\t\t");
	}
	
	// Méthode toString pour obtenir une représentation textuelle du compte épargne
	@Override
	public String toString() {
		return "Compte Epargne" +getCode()+"-> ( "+"Solde :"+solde+" DH)";
	}
	
	
	

}
